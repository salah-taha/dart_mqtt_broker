import 'broker.dart';

void main() async {
  final broker = MQTTBroker(host: '127.0.0.1', port: 1883);
  broker.start();
}
