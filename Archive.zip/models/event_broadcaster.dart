import 'dart:io';
import 'dart:typed_data';

class EventBroadcaster {
  final List<Function(RawSocket client)> onConnectHandlers = [];
  final List<Function(RawSocket client, Uint8List data)> onPublishHandlers = [];
  final List<Function(RawSocket client, Uint8List data)> onSubscribeHandlers = [];
  final List<Function(RawSocket client, Uint8List data)> onUnsubscribeHandlers = [];
  final List<Function(RawSocket client)> onPingHandlers = [];
  final List<Function(RawSocket client)> onDisconnectHandlers = [];

  void onConnect(Function(RawSocket client) handler) {
    onConnectHandlers.add(handler);
  }

  void onPublish(Function(RawSocket client, Uint8List data) handler) {
    onPublishHandlers.add(handler);
  }

  void onSubscribe(Function(RawSocket client, Uint8List data) handler) {
    onSubscribeHandlers.add(handler);
  }

  void onUnsubscribe(Function(RawSocket client, Uint8List data) handler) {
    onUnsubscribeHandlers.add(handler);
  }

  void onPing(Function(RawSocket client) handler) {
    onPingHandlers.add(handler);
  }

  void onDisconnect(Function(RawSocket client) handler) {
    onDisconnectHandlers.add(handler);
  }

  void triggerConnect(RawSocket client) {
    for (var handler in onConnectHandlers) {
      handler(client);
    }
  }

  void triggerPublish(RawSocket client, Uint8List data) {
    for (var handler in onPublishHandlers) {
      handler(client, data);
    }
  }

  void triggerSubscribe(RawSocket client, Uint8List data) {
    for (var handler in onSubscribeHandlers) {
      handler(client, data);
    }
  }

  void triggerUnsubscribe(RawSocket client, Uint8List data) {
    for (var handler in onUnsubscribeHandlers) {
      handler(client, data);
    }
  }

  void triggerPing(RawSocket client) {
    for (var handler in onPingHandlers) {
      handler(client);
    }
  }
  void triggerUnsupported(RawSocket client, Uint8List data) {
    for (var handler in onPublishHandlers) {
      handler(client, data);
    }
  }
  

  void triggerDisconnect(RawSocket client) {
    for (var handler in onDisconnectHandlers) {
      handler(client);
    }
  }
}
