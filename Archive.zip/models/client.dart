import 'dart:io';
import 'dart:typed_data';

class Client {
  RawSocket socket;
  final String clientId;
  final bool cleanSession;
  final List<String> subscriptions = [];
  final List<Uint8List> pendingMessages = [];
  final String? willTopic;
  final Uint8List? willMessage;
  final int willQos;
  final bool willRetain;

  Client({
    required this.socket,
    required this.clientId,
    this.cleanSession = true,
    this.willTopic,
    this.willMessage,
    this.willQos = 0,
    this.willRetain = false,
  });

  void addSubscription(String topic) {
    if (!subscriptions.contains(topic)) {
      subscriptions.add(topic);
    }
  }

  void removeSubscription(String topic) {
    subscriptions.remove(topic);
  }

  void addPendingMessage(Uint8List message) {
    pendingMessages.add(message);
  }

  void clearPendingMessages() {
    pendingMessages.clear();
  }
  /// Sends data to the client's socket
  void send(Uint8List data) {
    try {
      socket.write(data);
    } catch (e) {
      print('Error sending data to client $clientId: $e');
    }
  }
  @override
  String toString() {
    return 'Client(clientId: $clientId, cleanSession: $cleanSession, subscriptions: $subscriptions, pendingMessages: ${pendingMessages.length})';
  }
}