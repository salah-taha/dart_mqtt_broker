import 'dart:io';
import 'dart:typed_data';

void handlePing(RawSocket client, Uint8List data) {
  print('PINGREQ packet received');
  final pingResp = Uint8List.fromList([0xD0, 0x00]); // PINGRESP
  client.write(pingResp);
  print('PINGRESP sent');
}
