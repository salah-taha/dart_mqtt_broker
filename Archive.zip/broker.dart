import 'dart:io';
import 'dart:typed_data';

import 'handlers/connect_handler.dart';
import 'handlers/disconnect_handler.dart';
import 'handlers/ping_handler.dart';
import 'handlers/publish_handler.dart';
import 'handlers/subscribe_handler.dart';
import 'handlers/unsubscribe_handler.dart';
import 'models/client.dart';
import 'models/event_broadcaster.dart';
import 'models/topic.dart';

class MQTTBroker {
  final String host;
  final int port;
  final EventBroadcaster events = EventBroadcaster(); // Event broadcaster
  final Map<String, Client> sessionStore = {}; // Persistent sessions
  final Map<RawSocket, Client> activeClients = {}; // Active client connections
  final Map<String, Topic> topics = {}; // Topics and subscribers

  MQTTBroker({this.host = '0.0.0.0', this.port = 1883}); // Default: bind to all interfaces

  void start() async {
    try {
      final server = await RawServerSocket.bind(host, port);
      print('MQTT Broker started on $host:$port');

      await for (RawSocket client in server) {
        print('Client connected: ${client.address.address}');
        _handleClient(client);
      }
    } catch (e) {
      print('Failed to start MQTT Broker: $e');
    }
  }

  void _handleClient(RawSocket client) {
    client.listen((RawSocketEvent event) {
      if (event == RawSocketEvent.read) {
        final data = client.read();
        if (data != null) {
          _processPacket(client, Uint8List.fromList(data));
        }
      } else if (event == RawSocketEvent.closed) {
        print('Client disconnected: ${client.address.address}');
        handleDisconnect(client, activeClients, topics, sessionStore);
        events.triggerDisconnect(client); // Trigger onDisconnect event
      }
    });
  }

  void _processPacket(RawSocket client, Uint8List data) {
    final firstByte = data[0];
    final messageType = (firstByte & 0xF0) >> 4;

    switch (messageType) {
      case 1: // CONNECT
        handleConnect(client, data, sessionStore, activeClients);
        events.triggerConnect(client);
        break;
      case 3: // PUBLISH
        handlePublish(client, data, topics, sessionStore);
        events.triggerPublish(client, data);
        break;
      case 8: // SUBSCRIBE
        handleSubscribe(client, data, topics, activeClients);
        events.triggerSubscribe(client, data);
        break;
      case 10: // UNSUBSCRIBE
        handleUnsubscribe(client, data, topics, activeClients);
        events.triggerUnsubscribe(client, data);
        break;
      case 12: // PINGREQ
        handlePing(client, data);
        events.triggerPing(client);
        break;
      default:
        print('Unsupported MQTT packet type: $messageType');
        events.triggerUnsupported(client, data);
        break;
    }
  }
}
